coinList = function (params) {
    return 'test'
}
module.exports = { coinList }